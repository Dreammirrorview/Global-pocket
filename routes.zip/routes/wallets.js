const express = require('express');
const { verifyToken, adminOnly } = require('./auth');
const Wallet = require('../models/Wallet');
const Transaction = require('../models/Transaction');
const crypto = require('crypto');
const router = express.Router();

// Generate wallet address
const generateWalletAddress = (coin) => {
  const prefix = {
    'BTC': 'bc1',
    'ETH': '0x',
    'LTC': 'ltc1',
    'XRP': 'r',
    'DOGE': 'D',
    'USDT': '0x',
    'BNB': 'bnb',
    'ADA': 'addr',
    'DOT': '1',
    'SOL': 'sol'
  };
  
  const randomChars = crypto.randomBytes(20).toString('hex');
  return `${prefix[coin] || '0x'}${randomChars}`;
};

// Create new wallet
router.post('/create', verifyToken, async (req, res) => {
  try {
    const { coin, network, isMain } = req.body;
    const userId = req.user.id;

    // Check if wallet already exists
    const existingWallet = await Wallet.findOne({ userId, coin });
    if (existingWallet) {
      return res.status(400).json({ 
        success: false, 
        message: 'Wallet for this coin already exists' 
      });
    }

    const walletAddress = generateWalletAddress(coin);
    const privateKey = crypto.randomBytes(32).toString('hex');

    const wallet = new Wallet({
      userId,
      coin,
      walletAddress,
      privateKey,
      network,
      isMain: isMain || false
    });

    await wallet.save();

    res.status(201).json({
      success: true,
      message: 'Wallet created successfully',
      wallet: {
        id: wallet._id,
        coin: wallet.coin,
        walletAddress: wallet.walletAddress,
        balance: wallet.balance,
        network: wallet.network,
        status: wallet.status
      }
    });
  } catch (error) {
    console.error('Create wallet error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error creating wallet' 
    });
  }
});

// Get all wallets for user
router.get('/user/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Only allow users to see their own wallets
    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const wallets = await Wallet.find({ userId, status: 'active' })
      .sort({ isMain: -1, createdAt: -1 });

    res.json({
      success: true,
      wallets
    });
  } catch (error) {
    console.error('Get wallets error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching wallets' 
    });
  }
});

// Get wallet by ID
router.get('/:walletId', verifyToken, async (req, res) => {
  try {
    const wallet = await Wallet.findById(req.params.walletId);

    if (!wallet) {
      return res.status(404).json({ 
        success: false, 
        message: 'Wallet not found' 
      });
    }

    // Check access
    if (req.user.type === 'user' && wallet.userId.toString() !== req.user.id) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    res.json({
      success: true,
      wallet
    });
  } catch (error) {
    console.error('Get wallet error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching wallet' 
    });
  }
});

// Withdraw from wallet
router.post('/withdraw', verifyToken, async (req, res) => {
  try {
    const { walletId, amount, toAddress, network, notes } = req.body;
    const userId = req.user.id;

    const wallet = await Wallet.findById(walletId);
    if (!wallet) {
      return res.status(404).json({ 
        success: false, 
        message: 'Wallet not found' 
      });
    }

    if (wallet.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    if (wallet.balance < amount) {
      return res.status(400).json({ 
        success: false, 
        message: 'Insufficient balance' 
      });
    }

    // Create transaction
    const transaction = new Transaction({
      userId,
      type: 'withdrawal',
      amount,
      currency: wallet.coin,
      fromWallet: walletId,
      fromAddress: wallet.walletAddress,
      toAddress,
      network,
      description: notes || `Withdraw ${amount} ${wallet.coin}`,
      category: 'crypto',
      fee: amount * 0.001, // 0.1% fee
      status: 'pending'
    });

    await transaction.save();

    // Freeze wallet balance
    wallet.balance -= amount;
    wallet.frozenBalance += amount;
    wallet.totalSent += amount;
    await wallet.save();

    res.status(201).json({
      success: true,
      message: 'Withdrawal request submitted',
      transaction: {
        id: transaction._id,
        amount: transaction.amount,
        status: transaction.status,
        toAddress: transaction.toAddress,
        network: transaction.network
      }
    });
  } catch (error) {
    console.error('Withdrawal error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error processing withdrawal' 
    });
  }
});

// Deposit to wallet
router.post('/deposit', verifyToken, async (req, res) => {
  try {
    const { walletId, amount, fromAddress, network, transactionHash } = req.body;
    const userId = req.user.id;

    const wallet = await Wallet.findById(walletId);
    if (!wallet) {
      return res.status(404).json({ 
        success: false, 
        message: 'Wallet not found' 
      });
    }

    if (wallet.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const transaction = new Transaction({
      userId,
      type: 'deposit',
      amount,
      currency: wallet.coin,
      toWallet: walletId,
      toAddress: wallet.walletAddress,
      fromAddress,
      network,
      transactionHash,
      description: `Deposit ${amount} ${wallet.coin}`,
      category: 'crypto',
      status: 'processing'
    });

    await transaction.save();

    res.status(201).json({
      success: true,
      message: 'Deposit recorded successfully',
      transaction: {
        id: transaction._id,
        amount: transaction.amount,
        status: transaction.status
      }
    });
  } catch (error) {
    console.error('Deposit error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error recording deposit' 
    });
  }
});

// Transfer between wallets
router.post('/transfer', verifyToken, async (req, res) => {
  try {
    const { fromWalletId, toWalletId, amount, notes } = req.body;
    const userId = req.user.id;

    const fromWallet = await Wallet.findById(fromWalletId);
    const toWallet = await Wallet.findById(toWalletId);

    if (!fromWallet || !toWallet) {
      return res.status(404).json({ 
        success: false, 
        message: 'One or both wallets not found' 
      });
    }

    if (fromWallet.userId.toString() !== userId || toWallet.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    if (fromWallet.balance < amount) {
      return res.status(400).json({ 
        success: false, 
        message: 'Insufficient balance' 
      });
    }

    // Execute transfer
    fromWallet.balance -= amount;
    toWallet.balance += amount;
    fromWallet.totalSent += amount;
    toWallet.totalReceived += amount;

    await fromWallet.save();
    await toWallet.save();

    // Create transaction record
    const transaction = new Transaction({
      userId,
      type: 'transfer',
      amount,
      currency: fromWallet.coin,
      fromWallet: fromWalletId,
      toWallet: toWalletId,
      fromAddress: fromWallet.walletAddress,
      toAddress: toWallet.walletAddress,
      network: fromWallet.network,
      description: notes || `Transfer ${amount} ${fromWallet.coin}`,
      category: 'crypto',
      status: 'completed',
      completedAt: new Date()
    });

    await transaction.save();

    res.json({
      success: true,
      message: 'Transfer completed successfully',
      transaction: {
        id: transaction._id,
        amount: transaction.amount,
        status: transaction.status
      }
    });
  } catch (error) {
    console.error('Transfer error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error processing transfer' 
    });
  }
});

// Get wallet balance
router.get('/:walletId/balance', verifyToken, async (req, res) => {
  try {
    const wallet = await Wallet.findById(req.params.walletId);

    if (!wallet) {
      return res.status(404).json({ 
        success: false, 
        message: 'Wallet not found' 
      });
    }

    if (req.user.type === 'user' && wallet.userId.toString() !== req.user.id) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    res.json({
      success: true,
      balance: {
        available: wallet.balance,
        frozen: wallet.frozenBalance,
        total: wallet.balance + wallet.frozenBalance,
        coin: wallet.coin
      }
    });
  } catch (error) {
    console.error('Get balance error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching balance' 
    });
  }
});

module.exports = router;