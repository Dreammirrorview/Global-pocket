const express = require('express');
const { verifyToken } = require('./auth');
const Trade = require('../models/Trade');
const User = require('../models/User');
const Wallet = require('../models/Wallet');
const router = express.Router();

// Get current crypto prices (simulated)
router.get('/prices', async (req, res) => {
  try {
    const coins = ['BTC', 'ETH', 'LTC', 'XRP', 'DOGE'];
    const prices = {};
    
    for (const coin of coins) {
      const basePrice = {
        'BTC': 45000,
        'ETH': 2500,
        'LTC': 70,
        'XRP': 0.5,
        'DOGE': 0.08
      };
      const variation = (Math.random() - 0.5) * basePrice[coin] * 0.02;
      prices[coin] = {
        price: (basePrice[coin] + variation).toFixed(2),
        change: (Math.random() - 0.5) * 5,
        volume: Math.floor(Math.random() * 1000000)
      };
    }

    res.json({
      success: true,
      prices,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('Get prices error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching prices' 
    });
  }
});

// Create new trade
router.post('/create', verifyToken, async (req, res) => {
  try {
    const { 
      type, tradeType, coin, pair, entryPrice, amount, 
      leverage, stopLoss, takeProfit, autoTrade, robotSettings 
    } = req.body;
    const userId = req.user.id;

    // Verify user has sufficient balance
    const user = await User.findById(userId);
    if (!user || user.accountBalance < amount) {
      return res.status(400).json({ 
        success: false, 
        message: 'Insufficient account balance' 
      });
    }

    const trade = new Trade({
      userId,
      type,
      tradeType,
      coin,
      pair,
      entryPrice,
      currentPrice: entryPrice,
      amount,
      leverage: leverage || 1,
      stopLoss,
      takeProfit,
      autoTrade: autoTrade || { enabled: false },
      robotSettings: robotSettings || { enabled: false },
      status: 'active'
    });

    // Deduct amount from account balance
    user.accountBalance -= amount;
    await user.save();

    await trade.save();

    res.status(201).json({
      success: true,
      message: 'Trade created successfully',
      trade: {
        id: trade._id,
        type: trade.type,
        tradeType: trade.tradeType,
        coin: trade.coin,
        entryPrice: trade.entryPrice,
        amount: trade.amount,
        leverage: trade.leverage,
        status: trade.status
      }
    });
  } catch (error) {
    console.error('Create trade error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error creating trade' 
    });
  }
});

// Get all trades for user
router.get('/user/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;
    const { status, type } = req.query;

    // Only allow users to see their own trades
    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const query = { userId };
    if (status) query.status = status;
    if (type) query.type = type;

    const trades = await Trade.find(query)
      .sort({ openedAt: -1 })
      .limit(100);

    res.json({
      success: true,
      trades,
      count: trades.length
    });
  } catch (error) {
    console.error('Get trades error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching trades' 
    });
  }
});

// Get active trades
router.get('/active/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const trades = await Trade.find({ 
      userId, 
      status: 'active' 
    }).sort({ openedAt: -1 });

    res.json({
      success: true,
      trades
    });
  } catch (error) {
    console.error('Get active trades error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching active trades' 
    });
  }
});

// Close trade
router.post('/:tradeId/close', verifyToken, async (req, res) => {
  try {
    const { tradeId } = req.params;
    const { exitPrice } = req.body;
    const userId = req.user.id;

    const trade = await Trade.findById(tradeId);
    if (!trade) {
      return res.status(404).json({ 
        success: false, 
        message: 'Trade not found' 
      });
    }

    if (trade.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    if (trade.status !== 'active') {
      return res.status(400).json({ 
        success: false, 
        message: 'Trade is not active' 
      });
    }

    // Calculate profit/loss
    const priceDiff = (exitPrice || trade.currentPrice) - trade.entryPrice;
    const profit = priceDiff * trade.amount * trade.leverage;

    // Update trade
    trade.exitPrice = exitPrice || trade.currentPrice;
    trade.profit = profit;
    trade.status = 'completed';
    trade.closedAt = new Date();

    await trade.save();

    // Update user balance
    const user = await User.findById(userId);
    user.accountBalance += trade.amount + profit;
    user.totalProfit += profit;
    await user.save();

    res.json({
      success: true,
      message: 'Trade closed successfully',
      trade: {
        id: trade._id,
        profit: trade.profit,
        exitPrice: trade.exitPrice,
        status: trade.status
      }
    });
  } catch (error) {
    console.error('Close trade error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error closing trade' 
    });
  }
});

// Enable/disable auto trading
router.post('/:tradeId/auto-trade', verifyToken, async (req, res) => {
  try {
    const { tradeId } = req.params;
    const { enabled, strategy, riskLevel } = req.body;
    const userId = req.user.id;

    const trade = await Trade.findById(tradeId);
    if (!trade) {
      return res.status(404).json({ 
        success: false, 
        message: 'Trade not found' 
      });
    }

    if (trade.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    trade.autoTrade = {
      enabled,
      strategy: strategy || trade.autoTrade.strategy,
      riskLevel: riskLevel || trade.autoTrade.riskLevel
    };

    await trade.save();

    res.json({
      success: true,
      message: `Auto trading ${enabled ? 'enabled' : 'disabled'}`,
      trade: {
        id: trade._id,
        autoTrade: trade.autoTrade
      }
    });
  } catch (error) {
    console.error('Auto trade error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error updating auto trade settings' 
    });
  }
});

// Enable/disable robot trading
router.post('/:tradeId/robot', verifyToken, async (req, res) => {
  try {
    const { tradeId } = req.params;
    const { enabled, algorithm, parameters } = req.body;
    const userId = req.user.id;

    const trade = await Trade.findById(tradeId);
    if (!trade) {
      return res.status(404).json({ 
        success: false, 
        message: 'Trade not found' 
      });
    }

    if (trade.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    trade.robotSettings = {
      enabled,
      algorithm: algorithm || trade.robotSettings.algorithm,
      parameters: parameters || trade.robotSettings.parameters
    };

    await trade.save();

    res.json({
      success: true,
      message: `Robot trading ${enabled ? 'enabled' : 'disabled'}`,
      trade: {
        id: trade._id,
        robotSettings: trade.robotSettings
      }
    });
  } catch (error) {
    console.error('Robot trade error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error updating robot settings' 
    });
  }
});

// Get trade statistics
router.get('/stats/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const stats = await Trade.aggregate([
      { $match: { userId: mongoose.Types.ObjectId(userId) } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          totalAmount: { $sum: '$amount' },
          totalProfit: { $sum: '$profit' }
        }
      }
    ]);

    const totalTrades = await Trade.countDocuments({ userId });
    const activeTrades = await Trade.countDocuments({ userId, status: 'active' });

    res.json({
      success: true,
      stats: {
        totalTrades,
        activeTrades,
        byStatus: stats
      }
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching trade statistics' 
    });
  }
});

module.exports = router;