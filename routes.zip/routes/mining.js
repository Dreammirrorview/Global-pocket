const express = require('express');
const { verifyToken } = require('./auth');
const MiningOperation = require('../models/MiningOperation');
const Wallet = require('../models/Wallet');
const User = require('../models/User');
const router = express.Router();

// Start mining operation
router.post('/start', verifyToken, async (req, res) => {
  try {
    const { walletId, coin, hashrate, powerConsumption, settings } = req.body;
    const userId = req.user.id;

    // Verify wallet exists and belongs to user
    const wallet = await Wallet.findOne({ _id: walletId, userId });
    if (!wallet) {
      return res.status(404).json({ 
        success: false, 
        message: 'Wallet not found' 
      });
    }

    // Check if mining already active for this wallet
    const existingMining = await MiningOperation.findOne({ 
      walletId, 
      status: 'active' 
    });
    
    if (existingMining) {
      return res.status(400).json({ 
        success: false, 
        message: 'Mining already active for this wallet' 
      });
    }

    const mining = new MiningOperation({
      userId,
      walletId,
      coin,
      hashrate,
      powerConsumption,
      settings: settings || {},
      status: 'active',
      startedAt: new Date()
    });

    // Update wallet mining status
    wallet.miningEnabled = true;
    wallet.miningHashrate = hashrate;
    await wallet.save();

    await mining.save();

    res.status(201).json({
      success: true,
      message: 'Mining operation started successfully',
      mining: {
        id: mining._id,
        coin: mining.coin,
        hashrate: mining.hashrate,
        status: mining.status,
        startedAt: mining.startedAt
      }
    });
  } catch (error) {
    console.error('Start mining error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error starting mining operation' 
    });
  }
});

// Get mining operations for user
router.get('/user/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const miningOperations = await MiningOperation.find({ userId })
      .populate('walletId', 'coin walletAddress balance')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      miningOperations
    });
  } catch (error) {
    console.error('Get mining operations error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching mining operations' 
    });
  }
});

// Get active mining operations
router.get('/active/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const activeMining = await MiningOperation.find({ 
      userId, 
      status: 'active' 
    }).populate('walletId', 'coin walletAddress balance');

    res.json({
      success: true,
      activeMining
    });
  } catch (error) {
    console.error('Get active mining error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching active mining' 
    });
  }
});

// Stop mining operation
router.post('/:miningId/stop', verifyToken, async (req, res) => {
  try {
    const { miningId } = req.params;
    const userId = req.user.id;

    const mining = await MiningOperation.findById(miningId);
    if (!mining) {
      return res.status(404).json({ 
        success: false, 
        message: 'Mining operation not found' 
      });
    }

    if (mining.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    mining.status = 'stopped';
    mining.completedAt = new Date();
    await mining.save();

    // Update wallet mining status
    const wallet = await Wallet.findById(mining.walletId);
    if (wallet) {
      wallet.miningEnabled = false;
      wallet.miningHashrate = 0;
      await wallet.save();
    }

    res.json({
      success: true,
      message: 'Mining operation stopped successfully',
      mining: {
        id: mining._id,
        status: mining.status,
        minedAmount: mining.minedAmount,
        completedAt: mining.completedAt
      }
    });
  } catch (error) {
    console.error('Stop mining error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error stopping mining operation' 
    });
  }
});

// Pause mining operation
router.post('/:miningId/pause', verifyToken, async (req, res) => {
  try {
    const { miningId } = req.params;
    const userId = req.user.id;

    const mining = await MiningOperation.findById(miningId);
    if (!mining) {
      return res.status(404).json({ 
        success: false, 
        message: 'Mining operation not found' 
      });
    }

    if (mining.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    mining.status = 'paused';
    await mining.save();

    res.json({
      success: true,
      message: 'Mining operation paused successfully',
      mining: {
        id: mining._id,
        status: mining.status
      }
    });
  } catch (error) {
    console.error('Pause mining error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error pausing mining operation' 
    });
  }
});

// Resume mining operation
router.post('/:miningId/resume', verifyToken, async (req, res) => {
  try {
    const { miningId } = req.params;
    const userId = req.user.id;

    const mining = await MiningOperation.findById(miningId);
    if (!mining) {
      return res.status(404).json({ 
        success: false, 
        message: 'Mining operation not found' 
      });
    }

    if (mining.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    mining.status = 'active';
    await mining.save();

    res.json({
      success: true,
      message: 'Mining operation resumed successfully',
      mining: {
        id: mining._id,
        status: mining.status
      }
    });
  } catch (error) {
    console.error('Resume mining error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error resuming mining operation' 
      });
  }
});

// Withdraw mined coins
router.post('/:miningId/withdraw', verifyToken, async (req, res) => {
  try {
    const { miningId, amount, toAddress } = req.body;
    const userId = req.user.id;

    const mining = await MiningOperation.findById(miningId);
    if (!mining) {
      return res.status(404).json({ 
        success: false, 
        message: 'Mining operation not found' 
      });
    }

    if (mining.userId.toString() !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    if (mining.minedAmount < amount) {
      return res.status(400).json({ 
        success: false, 
        message: 'Insufficient mined amount' 
      });
    }

    mining.minedAmount -= amount;
    await mining.save();

    // Add rewards record
    mining.rewards.push({
      amount: amount,
      timestamp: new Date()
    });

    res.json({
      success: true,
      message: 'Mined coins withdrawn successfully',
      mining: {
        id: mining._id,
        minedAmount: mining.minedAmount,
        withdrawnAmount: amount
      }
    });
  } catch (error) {
    console.error('Withdraw mined coins error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error withdrawing mined coins' 
    });
  }
});

// Get mining statistics
router.get('/stats/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const stats = await MiningOperation.aggregate([
      { $match: { userId: mongoose.Types.ObjectId(userId) } },
      {
        $group: {
          _id: '$coin',
          totalMined: { $sum: '$minedAmount' },
          totalHashrate: { $sum: '$hashrate' },
          activeOperations: { $sum: { $cond: ['$status', 'active', 1, 0] } }
        }
      }
    ]);

    const totalMined = await MiningOperation.aggregate([
      { $match: { userId: mongoose.Types.ObjectId(userId) } },
      {
        $group: {
          _id: null,
          total: { $sum: '$minedAmount' }
        }
      }
    ]);

    res.json({
      success: true,
      stats: {
        byCoin: stats,
        totalMined: totalMined[0]?.total || 0
      }
    });
  } catch (error) {
    console.error('Get mining stats error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching mining statistics' 
    });
  }
});

module.exports = router;