const express = require('express');
const { verifyToken } = require('./auth');
const User = require('../models/User');
const router = express.Router();

// Get user profile
router.get('/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    // Only allow users to see their own profile
    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const user = await User.findById(userId).select('-password');

    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: 'User not found' 
      });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching user profile' 
    });
  }
});

// Update user profile
router.put('/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;
    const { fullName, phone, country } = req.body;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: 'User not found' 
      });
    }

    if (fullName) user.fullName = fullName;
    if (phone) user.phone = phone;
    if (country) user.country = country;

    await user.save();

    res.json({
      success: true,
      message: 'Profile updated successfully',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        phone: user.phone,
        country: user.country
      }
    });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error updating user profile' 
    });
  }
});

// Get user balance
router.get('/:userId/balance', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: 'User not found' 
      });
    }

    res.json({
      success: true,
      balance: {
        accountBalance: user.accountBalance,
        gainBalance: user.gainBalance,
        totalDeposits: user.totalDeposits,
        totalWithdrawals: user.totalWithdrawals,
        totalProfit: user.totalProfit
      }
    });
  } catch (error) {
    console.error('Get balance error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching user balance' 
    });
  }
});

// Add funds to user account (admin only)
router.post('/:userId/add-funds', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;
    const { amount, description } = req.body;

    if (req.user.type !== 'admin') {
      return res.status(403).json({ 
        success: false, 
        message: 'Admin access required' 
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: 'User not found' 
      });
    }

    user.accountBalance += amount;
    user.totalDeposits += amount;
    await user.save();

    res.json({
      success: true,
      message: 'Funds added successfully',
      balance: {
        accountBalance: user.accountBalance,
        totalDeposits: user.totalDeposits
      }
    });
  } catch (error) {
    console.error('Add funds error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error adding funds' 
    });
  }
});

module.exports = router;