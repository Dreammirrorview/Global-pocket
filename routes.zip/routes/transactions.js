const express = require('express');
const { verifyToken } = require('./auth');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const Wallet = require('../models/Wallet');
const router = express.Router();

// Get all transactions for user
router.get('/user/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;
    const { type, status, limit = 50 } = req.query;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const query = { userId };
    if (type) query.type = type;
    if (status) query.status = status;

    const transactions = await Transaction.find(query)
      .populate('fromWallet', 'coin walletAddress')
      .populate('toWallet', 'coin walletAddress')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    res.json({
      success: true,
      transactions,
      count: transactions.length
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching transactions' 
    });
  }
});

// Get transaction by ID
router.get('/:transactionId', verifyToken, async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.transactionId)
      .populate('fromWallet', 'coin walletAddress')
      .populate('toWallet', 'coin walletAddress');

    if (!transaction) {
      return res.status(404).json({ 
        success: false, 
        message: 'Transaction not found' 
      });
    }

    if (req.user.type === 'user' && transaction.userId.toString() !== req.user.id) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    res.json({
      success: true,
      transaction
    });
  } catch (error) {
    console.error('Get transaction error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching transaction' 
    });
  }
});

// Bank deposit (Global Bank Nigeria)
router.post('/deposit/bank', verifyToken, async (req, res) => {
  try {
    const { amount, bankName, accountNumber, accountName, description } = req.body;
    const userId = req.user.id;

    if (!bankName || !accountNumber || !accountName) {
      return res.status(400).json({ 
        success: false, 
        message: 'Bank details are required' 
      });
    }

    const transaction = new Transaction({
      userId,
      type: 'deposit',
      amount,
      currency: 'NGN',
      network: 'bank-transfer',
      bankDetails: {
        bankName,
        accountNumber,
        accountName
      },
      description: description || `Bank deposit of ${amount} NGN from ${bankName}`,
      category: 'fiat',
      status: 'processing'
    });

    await transaction.save();

    res.status(201).json({
      success: true,
      message: 'Bank deposit request submitted',
      transaction: {
        id: transaction._id,
        amount: transaction.amount,
        status: transaction.status,
        bankDetails: transaction.bankDetails
      }
    });
  } catch (error) {
    console.error('Bank deposit error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error processing bank deposit' 
    });
  }
});

// Bank withdrawal
router.post('/withdraw/bank', verifyToken, async (req, res) => {
  try {
    const { amount, bankName, accountNumber, accountName, routingNumber, description } = req.body;
    const userId = req.user.id;

    const user = await User.findById(userId);
    if (!user || user.accountBalance < amount) {
      return res.status(400).json({ 
        success: false, 
        message: 'Insufficient account balance' 
      });
    }

    if (!bankName || !accountNumber || !accountName) {
      return res.status(400).json({ 
        success: false, 
        message: 'Bank details are required' 
      });
    }

    const transaction = new Transaction({
      userId,
      type: 'withdrawal',
      amount,
      currency: 'NGN',
      network: 'bank-transfer',
      bankDetails: {
        bankName,
        accountNumber,
        accountName,
        routingNumber
      },
      description: description || `Bank withdrawal of ${amount} NGN to ${bankName}`,
      category: 'fiat',
      status: 'pending',
      fee: amount * 0.02 // 2% fee for bank withdrawals
    });

    await transaction.save();

    // Deduct from account balance
    user.accountBalance -= amount + transaction.fee;
    user.totalWithdrawals += amount;
    await user.save();

    res.status(201).json({
      success: true,
      message: 'Bank withdrawal request submitted',
      transaction: {
        id: transaction._id,
        amount: transaction.amount,
        fee: transaction.fee,
        status: transaction.status,
        bankDetails: transaction.bankDetails
      }
    });
  } catch (error) {
    console.error('Bank withdrawal error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error processing bank withdrawal' 
    });
  }
});

// Card payment deposit
router.post('/deposit/card', verifyToken, async (req, res) => {
  try {
    const { amount, cardNumber, cardHolder, expiryDate, cvv, description } = req.body;
    const userId = req.user.id;

    const transaction = new Transaction({
      userId,
      type: 'deposit',
      amount,
      currency: 'USD',
      network: 'card-payment',
      description: description || `Card payment deposit of ${amount} USD`,
      category: 'fiat',
      status: 'processing',
      metadata: {
        cardLast4: cardNumber.slice(-4),
        cardHolder
      }
    });

    await transaction.save();

    res.status(201).json({
      success: true,
      message: 'Card deposit request submitted',
      transaction: {
        id: transaction._id,
        amount: transaction.amount,
        status: transaction.status
      }
    });
  } catch (error) {
    console.error('Card deposit error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error processing card deposit' 
    });
  }
});

// Get transaction statistics
router.get('/stats/:userId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;

    if (req.user.type === 'user' && req.user.id !== userId) {
      return res.status(403).json({ 
        success: false, 
        message: 'Access denied' 
      });
    }

    const stats = await Transaction.aggregate([
      { $match: { userId: mongoose.Types.ObjectId(userId) } },
      {
        $group: {
          _id: '$type',
          count: { $sum: 1 },
          totalAmount: { $sum: '$amount' },
          pending: { $sum: { $cond: ['$status', 'pending', 1, 0] } },
          completed: { $sum: { $cond: ['$status', 'completed', 1, 0] } }
        }
      }
    ]);

    const totalVolume = await Transaction.aggregate([
      { $match: { userId: mongoose.Types.ObjectId(userId) } },
      {
        $group: {
          _id: null,
          total: { $sum: '$amount' }
        }
      }
    ]);

    res.json({
      success: true,
      stats: {
        byType: stats,
        totalVolume: totalVolume[0]?.total || 0
      }
    });
  } catch (error) {
    console.error('Get transaction stats error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching transaction statistics' 
    });
  }
});

module.exports = router;