# create-jest

> Getting started with Jest with a single command

```bash
npm init jest@latest
# Or for Yarn
yarn create jest
# Or for pnpm
pnpm create jest
```
