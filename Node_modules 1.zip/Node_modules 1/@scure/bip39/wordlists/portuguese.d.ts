export declare const wordlist: string[];
//# sourceMappingURL=portuguese.d.ts.map