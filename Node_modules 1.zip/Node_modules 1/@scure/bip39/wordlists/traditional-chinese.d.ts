export declare const wordlist: string[];
//# sourceMappingURL=traditional-chinese.d.ts.map