"use strict";

var resolveSeparated = require("./resolve-separated");

module.exports = function (code/*, limit*/) { return resolveSeparated(code, ",", arguments[1]); };
