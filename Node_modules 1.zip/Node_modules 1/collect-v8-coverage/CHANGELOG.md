## [1.0.3](https://github.com/SimenB/collect-v8-coverage/compare/v1.0.2...v1.0.3) (2025-10-15)


### Bug Fixes

* enable and disable debugger for more accurate coverage ([#235](https://github.com/SimenB/collect-v8-coverage/issues/235)) ([44fdef5](https://github.com/SimenB/collect-v8-coverage/commit/44fdef5d9110664da487f973f27aef134e0b035f))

## [1.0.2](https://github.com/SimenB/collect-v8-coverage/compare/v1.0.1...v1.0.2) (2023-07-05)


### Bug Fixes

* workaround for networked filesystems on Windows ([#174](https://github.com/SimenB/collect-v8-coverage/issues/174)) ([4de72ea](https://github.com/SimenB/collect-v8-coverage/commit/4de72ea976228d6d8b7fb78207c1187aa58ddf50))

## [1.0.1](https://github.com/SimenB/collect-v8-coverage/compare/v1.0.0...v1.0.1) (2020-04-02)

### Bug Fixes

- link to repo from package.json ([cf54d65](https://github.com/SimenB/collect-v8-coverage/commit/cf54d659f23afd411cd0ff752e69fa97d2ab1707))

# 1.0.0 (2019-12-16)

### Features

- initial commit ([57e2041](https://github.com/SimenB/collect-v8-coverage/commit/57e20413f385d7730c5684b1852c14777583807e))
