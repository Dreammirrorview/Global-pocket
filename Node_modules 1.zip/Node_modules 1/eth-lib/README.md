## Eth-Lib

Lightweight Ethereum libraries. This is a temporary repository which will be used as the basis of an implementation on Idris (or similar).
