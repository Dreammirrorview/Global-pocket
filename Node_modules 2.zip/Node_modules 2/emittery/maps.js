const anyMap = new WeakMap();
const eventsMap = new WeakMap();
const producersMap = new WeakMap();

module.exports = {
	anyMap,
	eventsMap,
	producersMap
};
