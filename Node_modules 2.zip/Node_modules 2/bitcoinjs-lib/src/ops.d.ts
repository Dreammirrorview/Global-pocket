declare const OPS: {
    [key: string]: number;
};
declare const REVERSE_OPS: {
    [key: number]: string;
};
export { OPS, REVERSE_OPS };
