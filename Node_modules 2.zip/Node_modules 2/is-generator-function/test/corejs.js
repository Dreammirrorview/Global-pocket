'use strict';

// @ts-ignore
require('core-js');

require('./');
