Please report any security vulnerabilities to security@dotenvx.com. 
