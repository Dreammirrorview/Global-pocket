# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [1.1.0](https://github.com/medikoo/next-tick/compare/v1.0.0...v1.1.0) (2020-02-11)

### Features

* Add support for queueMicrotask (Closes [#13](https://github.com/medikoo/next-tick/issues/13)) ([471986e](https://github.com/medikoo/next-tick/commit/471986ee5f7179a498850cc03138a5ed5b9a248c))

## Changelog for previous versions

See `CHANGES` file
