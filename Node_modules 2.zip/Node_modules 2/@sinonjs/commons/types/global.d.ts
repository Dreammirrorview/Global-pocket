export = globalObject;
/**
 * A reference to the global object
 * @type {object} globalObject
 */
declare var globalObject: object;
