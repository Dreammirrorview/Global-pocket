// Global variables
const API_BASE_URL = 'http://localhost:5000/api';
let token = localStorage.getItem('adminToken');
let adminUser = JSON.parse(localStorage.getItem('adminUser') || '{}');
let socket = null;

// Check authentication
if (!token) {
    window.location.href = '/index.html';
}

// Initialize socket connection
function initializeSocket() {
    socket = io('http://localhost:5000', {
        auth: { token }
    });

    socket.on('connect', () => {
        console.log('Socket connected:', socket.id);
        socket.emit('join-room', 'admin');
    });

    socket.on('price-update', (prices) => {
        updateMarketTable(prices);
    });

    socket.on('mining-update', (data) => {
        updateMiningStats(data);
    });

    socket.on('trade-executed', (data) => {
        addActivityItem(data);
    });

    socket.on('disconnect', () => {
        console.log('Socket disconnected');
    });
}

// Navigation
document.addEventListener('DOMContentLoaded', () => {
    initializeSocket();
    loadDashboardData();
    setupNavigation();
    setupEventListeners();
});

function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            if (item.id === 'logoutBtn') {
                e.preventDefault();
                handleLogout();
                return;
            }
            
            const page = item.getAttribute('data-page');
            if (page) {
                navigateToPage(page);
            }
        });
    });
}

function navigateToPage(page) {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('data-page') === page) {
            item.classList.add('active');
        }
    });

    const pageTitle = document.getElementById('pageTitle');
    pageTitle.textContent = page.charAt(0).toUpperCase() + page.slice(1);
}

function setupEventListeners() {
    // Menu toggle
    document.getElementById('menuToggle').addEventListener('click', () => {
        document.querySelector('.sidebar').classList.toggle('active');
    });

    // Update admin info
    if (adminUser.fullName) {
        document.getElementById('adminName').textContent = adminUser.fullName;
    }
}

// API Functions
async function fetchAPI(endpoint, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        }
    };

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...defaultOptions,
        ...options
    });

    if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
    }

    return response.json();
}

// Load Dashboard Data
async function loadDashboardData() {
    try {
        // Load stats
        await updateStats();
        
        // Load market data
        await loadMarketData();
        
        // Load recent activity
        await loadRecentActivity();
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showError('Failed to load dashboard data');
    }
}

async function updateStats() {
    try {
        // Simulate stats (replace with real API calls)
        document.getElementById('totalUsers').textContent = '1,234';
        document.getElementById('totalVolume').textContent = '$2.5M';
        document.getElementById('activeMining').textContent = '89';
        document.getElementById('pendingTx').textContent = '45';
    } catch (error) {
        console.error('Error updating stats:', error);
    }
}

async function loadMarketData() {
    try {
        const response = await fetchAPI('/trading/prices');
        if (response.success) {
            updateMarketTable(response.prices);
        }
    } catch (error) {
        console.error('Error loading market data:', error);
    }
}

function updateMarketTable(prices) {
    const tbody = document.getElementById('marketTableBody');
    tbody.innerHTML = '';

    const coinIcons = {
        'BTC': 'fab fa-bitcoin',
        'ETH': 'fab fa-ethereum',
        'LTC': 'fas fa-coins',
        'XRP': 'fas fa-times',
        'DOGE': 'fas fa-dog'
    };

    const coinColors = {
        'BTC': '#f7931a',
        'ETH': '#627eea',
        'LTC': '#345d9d',
        'XRP': '#23292f',
        'DOGE': '#c2a633'
    };

    Object.entries(prices).forEach(([coin, data]) => {
        const row = document.createElement('tr');
        const isPositive = data.change >= 0;
        
        row.innerHTML = `
            <td>
                <div class="coin-cell">
                    <div class="coin-icon" style="background: ${coinColors[coin]}">
                        <i class="${coinIcons[coin]}"></i>
                    </div>
                    <span>${coin}</span>
                </div>
            </td>
            <td>$${parseFloat(data.price).toLocaleString()}</td>
            <td class="${isPositive ? 'positive' : 'negative'}">
                ${isPositive ? '+' : ''}${data.change.toFixed(2)}%
            </td>
            <td>${data.volume.toLocaleString()}</td>
            <td>
                <button class="trade-btn" onclick="openTradeModal('${coin}')">Trade</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

async function loadRecentActivity() {
    try {
        const activityList = document.getElementById('activityList');
        
        // Sample activity data (replace with real API calls)
        const activities = [
            {
                type: 'trade',
                title: 'New trade opened',
                user: 'John Doe',
                amount: '$5,000',
                time: '2 minutes ago'
            },
            {
                type: 'mining',
                title: 'Mining reward received',
                user: 'Jane Smith',
                amount: '0.0025 BTC',
                time: '5 minutes ago'
            },
            {
                type: 'deposit',
                title: 'Deposit confirmed',
                user: 'Bob Johnson',
                amount: '$10,000',
                time: '10 minutes ago'
            },
            {
                type: 'withdrawal',
                title: 'Withdrawal processed',
                user: 'Alice Brown',
                amount: '$2,500',
                time: '15 minutes ago'
            }
        ];

        activityList.innerHTML = activities.map(activity => createActivityItem(activity)).join('');
        
    } catch (error) {
        console.error('Error loading activity:', error);
    }
}

function createActivityItem(activity) {
    const icons = {
        'trade': 'fas fa-chart-line',
        'mining': 'fas fa-hammer',
        'deposit': 'fas fa-arrow-down',
        'withdrawal': 'fas fa-arrow-up'
    };

    const colors = {
        'trade': '#339af0',
        'mining': '#51cf66',
        'deposit': '#40c057',
        'withdrawal': '#ff6b6b'
    };

    return `
        <div class="activity-item">
            <div class="activity-icon" style="background: ${colors[activity.type]}">
                <i class="${icons[activity.type]}"></i>
            </div>
            <div class="activity-content">
                <div class="activity-title">${activity.title}</div>
                <div class="activity-time">${activity.user} • ${activity.time}</div>
            </div>
            <div class="activity-amount">${activity.amount}</div>
        </div>
    `;
}

function addActivityItem(data) {
    const activityList = document.getElementById('activityList');
    const newActivity = createActivityItem({
        type: 'trade',
        title: 'Auto trade executed',
        user: 'System',
        amount: `$${data.profit.toFixed(2)}`,
        time: 'Just now'
    });
    
    activityList.insertAdjacentHTML('afterbegin', newActivity);
}

// Modal Functions
function showModal(modalType) {
    const modalOverlay = document.getElementById('modalOverlay');
    const modalContainer = document.getElementById('modalContainer');
    
    let modalContent = '';
    
    switch(modalType) {
        case 'createUser':
            modalContent = createUserModal();
            break;
        case 'createWallet':
            modalContent = createWalletModal();
            break;
        case 'startMining':
            modalContent = startMiningModal();
            break;
        case 'approveTx':
            modalContent = approveTxModal();
            break;
    }
    
    modalContainer.innerHTML = modalContent;
    modalOverlay.style.display = 'flex';
}

function closeModal() {
    document.getElementById('modalOverlay').style.display = 'none';
}

function createUserModal() {
    return `
        <div class="modal-header">
            <h2>Create New User</h2>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form id="createUserForm">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="fullName" required>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" name="phone">
            </div>
            <div class="form-group">
                <label>Country</label>
                <select name="country">
                    <option value="Nigeria">Nigeria</option>
                    <option value="USA">USA</option>
                    <option value="UK">UK</option>
                </select>
            </div>
            <button type="submit" class="submit-btn">Create User</button>
        </form>
    `;
}

function createWalletModal() {
    return `
        <div class="modal-header">
            <h2>Create New Wallet</h2>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form id="createWalletForm">
            <div class="form-group">
                <label>Select User</label>
                <select name="userId" required>
                    <option value="">Select User</option>
                    <!-- Dynamic user options -->
                </select>
            </div>
            <div class="form-group">
                <label>Coin</label>
                <select name="coin" required>
                    <option value="BTC">Bitcoin</option>
                    <option value="ETH">Ethereum</option>
                    <option value="LTC">Litecoin</option>
                    <option value="XRP">Ripple</option>
                    <option value="DOGE">Dogecoin</option>
                </select>
            </div>
            <div class="form-group">
                <label>Network</label>
                <select name="network" required>
                    <option value="bitcoin">Bitcoin Network</option>
                    <option value="ethereum">Ethereum Network</option>
                    <option value="litecoin">Litecoin Network</option>
                    <option value="ripple">Ripple Network</option>
                    <option value="dogecoin">Dogecoin Network</option>
                </select>
            </div>
            <button type="submit" class="submit-btn">Create Wallet</button>
        </form>
    `;
}

function startMiningModal() {
    return `
        <div class="modal-header">
            <h2>Start Mining Operation</h2>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form id="startMiningForm">
            <div class="form-group">
                <label>Select Wallet</label>
                <select name="walletId" required>
                    <option value="">Select Wallet</option>
                    <!-- Dynamic wallet options -->
                </select>
            </div>
            <div class="form-group">
                <label>Coin</label>
                <select name="coin" required>
                    <option value="BTC">Bitcoin</option>
                    <option value="ETH">Ethereum</option>
                    <option value="LTC">Litecoin</option>
                    <option value="XRP">Ripple</option>
                    <option value="DOGE">Dogecoin</option>
                </select>
            </div>
            <div class="form-group">
                <label>Hashrate (TH/s)</label>
                <input type="number" name="hashrate" required min="1" step="0.1">
            </div>
            <div class="form-group">
                <label>Power Consumption (W)</label>
                <input type="number" name="powerConsumption" min="0">
            </div>
            <button type="submit" class="submit-btn">Start Mining</button>
        </form>
    `;
}

function approveTxModal() {
    return `
        <div class="modal-header">
            <h2>Approve Transactions</h2>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div id="pendingTransactions">
            <p>Loading pending transactions...</p>
        </div>
    `;
}

// Form Handlers
document.addEventListener('submit', async (e) => {
    if (e.target.id === 'createUserForm') {
        e.preventDefault();
        await handleCreateUser(e.target);
    } else if (e.target.id === 'createWalletForm') {
        e.preventDefault();
        await handleCreateWallet(e.target);
    } else if (e.target.id === 'startMiningForm') {
        e.preventDefault();
        await handleStartMining(e.target);
    }
});

async function handleCreateUser(form) {
    try {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        const response = await fetchAPI('/auth/register', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        
        if (response.success) {
            showSuccess('User created successfully');
            closeModal();
            await loadDashboardData();
        } else {
            showError(response.message || 'Failed to create user');
        }
    } catch (error) {
        console.error('Create user error:', error);
        showError('Error creating user');
    }
}

async function handleCreateWallet(form) {
    try {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        const response = await fetchAPI('/wallets/create', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        
        if (response.success) {
            showSuccess('Wallet created successfully');
            closeModal();
            await loadDashboardData();
        } else {
            showError(response.message || 'Failed to create wallet');
        }
    } catch (error) {
        console.error('Create wallet error:', error);
        showError('Error creating wallet');
    }
}

async function handleStartMining(form) {
    try {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        const response = await fetchAPI('/mining/start', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        
        if (response.success) {
            showSuccess('Mining started successfully');
            closeModal();
            await loadDashboardData();
        } else {
            showError(response.message || 'Failed to start mining');
        }
    } catch (error) {
        console.error('Start mining error:', error);
        showError('Error starting mining');
    }
}

// Utility Functions
function showSuccess(message) {
    alert('Success: ' + message);
}

function showError(message) {
    alert('Error: ' + message);
}

function handleLogout() {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminUser');
    window.location.href = '/index.html';
}

function updateMiningStats(data) {
    console.log('Mining update:', data);
}

function openTradeModal(coin) {
    showSuccess(`Opening trade for ${coin}`);
}

// Close modal when clicking outside
document.getElementById('modalOverlay').addEventListener('click', (e) => {
    if (e.target.id === 'modalOverlay') {
        closeModal();
    }
});