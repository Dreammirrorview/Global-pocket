const mongoose = require('mongoose');

const miningOperationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  walletId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Wallet',
    required: true
  },
  coin: {
    type: String,
    required: true,
    enum: ['BTC', 'ETH', 'LTC', 'XRP', 'DOGE']
  },
  hashrate: {
    type: Number,
    required: true
  },
  powerConsumption: {
    type: Number,
    default: 0
  },
  poolAddress: {
    type: String
  },
  status: {
    type: String,
    enum: ['pending', 'active', 'paused', 'stopped', 'completed'],
    default: 'pending'
  },
  minedAmount: {
    type: Number,
    default: 0
  },
  targetAmount: {
    type: Number
  },
  difficulty: {
    type: Number,
    default: 1
  },
  efficiency: {
    type: Number,
    default: 100
  },
  rewards: {
    type: [{
      amount: Number,
      timestamp: Date,
      blockHeight: Number
    }]
  },
  electricityCost: {
    type: Number,
    default: 0
  },
  maintenanceFee: {
    type: Number,
    default: 0
  },
  profitability: {
    daily: {
      type: Number,
      default: 0
    },
    monthly: {
      type: Number,
      default: 0
    }
  },
  hardware: {
    type: {
      type: String,
      enum: ['cpu', 'gpu', 'asic', 'fpga', 'cloud'],
      default: 'cpu'
    },
    model: String,
    quantity: Number
  },
  settings: {
    autoWithdraw: {
      type: Boolean,
      default: false
    },
    minWithdrawAmount: {
      type: Number,
      default: 0.001
    },
    reinvest: {
      type: Boolean,
      default: false
    },
    reinvestPercentage: {
      type: Number,
      default: 50
    }
  },
  lastRewardTime: {
    type: Date
  },
  startedAt: {
    type: Date
  },
  completedAt: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  owner: {
    type: String,
    default: 'Olawale Abdul-ganiyu'
  }
});

// Index for faster queries
miningOperationSchema.index({ userId: 1, status: 1 });
miningOperationSchema.index({ coin: 1, status: 1 });
miningOperationSchema.index({ walletId: 1 });

module.exports = mongoose.model('MiningOperation', miningOperationSchema);