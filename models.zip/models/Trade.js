const mongoose = require('mongoose');

const tradeSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['manual', 'auto', 'robot']
  },
  tradeType: {
    type: String,
    required: true,
    enum: ['buy', 'sell', 'long', 'short']
  },
  coin: {
    type: String,
    required: true,
    enum: ['BTC', 'ETH', 'LTC', 'XRP', 'DOGE', 'USDT', 'BNB', 'ADA', 'DOT', 'SOL']
  },
  pair: {
    type: String,
    required: true
  },
  entryPrice: {
    type: Number,
    required: true
  },
  currentPrice: {
    type: Number
  },
  exitPrice: {
    type: Number
  },
  amount: {
    type: Number,
    required: true
  },
  leverage: {
    type: Number,
    default: 1
  },
  profit: {
    type: Number,
    default: 0
  },
  loss: {
    type: Number,
    default: 0
  },
  stopLoss: {
    type: Number
  },
  takeProfit: {
    type: Number
  },
  status: {
    type: String,
    enum: ['pending', 'active', 'completed', 'cancelled', 'failed'],
    default: 'active'
  },
  autoTrade: {
    enabled: {
      type: Boolean,
      default: false
    },
    strategy: {
      type: String,
      enum: ['scalping', 'day-trading', 'swing', 'trend', 'arbitrage'],
      default: 'trend'
    },
    riskLevel: {
      type: String,
      enum: ['low', 'medium', 'high'],
      default: 'medium'
    },
    tradeFrequency: {
      type: Number,
      default: 1
    }
  },
  robotSettings: {
    enabled: {
      type: Boolean,
      default: false
    },
    algorithm: {
      type: String,
      enum: ['grid', 'dca', 'momentum', 'mean-reversion', 'breakout']
    },
    parameters: {
      type: Map,
      of: mongoose.Schema.Types.Mixed
    }
  },
  platform: {
    type: String,
    enum: ['web', 'mt4', 'mt5', 'api'],
    default: 'web'
  },
  margin: {
    type: Number,
    default: 0
  },
  liquidationPrice: {
    type: Number
  },
  fees: {
    type: Number,
    default: 0
  },
  notes: {
    type: String
  },
  openedAt: {
    type: Date,
    default: Date.now
  },
  closedAt: {
    type: Date
  },
  lastTradeTime: {
    type: Date
  },
  owner: {
    type: String,
    default: 'Olawale Abdul-ganiyu'
  }
});

// Index for faster queries
tradeSchema.index({ userId: 1, status: 1 });
tradeSchema.index({ coin: 1, status: 1 });
tradeSchema.index({ openedAt: -1 });

module.exports = mongoose.model('Trade', tradeSchema);