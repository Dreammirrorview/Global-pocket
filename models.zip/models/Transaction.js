const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['deposit', 'withdrawal', 'transfer', 'trade', 'mining', 'bonus', 'referral']
  },
  amount: {
    type: Number,
    required: true
  },
  currency: {
    type: String,
    required: true,
    default: 'USD'
  },
  fromWallet: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Wallet'
  },
  toWallet: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Wallet'
  },
  toAddress: {
    type: String
  },
  fromAddress: {
    type: String
  },
  network: {
    type: String,
    enum: ['bitcoin', 'ethereum', 'litecoin', 'ripple', 'dogecoin', 'tron', 'bank-transfer', 'card-payment'],
    required: true
  },
  bankDetails: {
    bankName: String,
    accountNumber: String,
    accountName: String,
    routingNumber: String
  },
  transactionHash: {
    type: String,
    unique: true
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'cancelled'],
    default: 'pending'
  },
  fee: {
    type: Number,
    default: 0
  },
  description: {
    type: String
  },
  category: {
    type: String,
    enum: ['crypto', 'fiat', 'trading', 'mining', 'other'],
    default: 'crypto'
  },
  confirmedAt: {
    type: Date
  },
  completedAt: {
    type: Date
  },
  metadata: {
    type: Map,
    of: String
  },
  adminApproval: {
    approved: {
      type: Boolean,
      default: false
    },
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Admin'
    },
    approvedAt: {
      type: Date
    },
    notes: {
      type: String
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  owner: {
    type: String,
    default: 'Olawale Abdul-ganiyu'
  }
});

// Index for faster queries
transactionSchema.index({ userId: 1, createdAt: -1 });
transactionSchema.index({ type: 1, status: 1 });
transactionSchema.index({ transactionHash: 1 });

module.exports = mongoose.model('Transaction', transactionSchema);