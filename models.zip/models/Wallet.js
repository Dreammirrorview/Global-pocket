const mongoose = require('mongoose');

const walletSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  coin: {
    type: String,
    required: true,
    enum: ['BTC', 'ETH', 'LTC', 'XRP', 'DOGE', 'USDT', 'BNB', 'ADA', 'DOT', 'SOL']
  },
  walletAddress: {
    type: String,
    required: true,
    unique: true
  },
  privateKey: {
    type: String
  },
  balance: {
    type: Number,
    default: 0
  },
  frozenBalance: {
    type: Number,
    default: 0
  },
  totalReceived: {
    type: Number,
    default: 0
  },
  totalSent: {
    type: Number,
    default: 0
  },
  network: {
    type: String,
    enum: ['bitcoin', 'ethereum', 'litecoin', 'ripple', 'dogecoin', 'tron', 'binance-smart-chain', 'solana'],
    default: 'bitcoin'
  },
  isMain: {
    type: Boolean,
    default: false
  },
  miningEnabled: {
    type: Boolean,
    default: false
  },
  miningHashrate: {
    type: Number,
    default: 0
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'frozen'],
    default: 'active'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  owner: {
    type: String,
    default: 'Olawale Abdul-ganiyu'
  }
});

// Index for faster queries
walletSchema.index({ userId: 1, coin: 1 });
walletSchema.index({ walletAddress: 1 });

module.exports = mongoose.model('Wallet', walletSchema);